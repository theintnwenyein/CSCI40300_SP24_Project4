#!/bin/bash

echo "Hello, this is a testing script."
echo "This script will print the current date and time:"
date
echo "First argument: $1"
echo "Second argument: $2"
echo "Number of provided args is $#"