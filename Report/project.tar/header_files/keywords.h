/**
* This contains keywords used for external comands.
* and methods used when program runs external comands.
*/
#include <string>


#ifndef H_Keywords
#define H_Keywords

void runCommand(std::string args);

#endif